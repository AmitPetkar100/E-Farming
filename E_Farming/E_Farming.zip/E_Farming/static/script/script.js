// Get the checkbox and the submit button
const checkbox = document.getElementById('checkbox');
const button = document.getElementById('submitButton');

// Function to enable/disable the button based on checkbox state
function toggleButton() {
    // If checkbox is checked, enable the button, otherwise disable it
    button.disabled = !checkbox.checked;
}

// Attach the toggleButton function to the checkbox's change event
checkbox.addEventListener('change', toggleButton);

// // Get the button element by its ID
// const button2 = document.getElementById('submitButton');

// // Function to display a pop-up message
// function showMessage() {
//     alert("Your Registration is successfull ,login now");
// }

// // Attach the showMessage function to the button's click event
// button2.addEventListener('click', showMessage);

// //  // Get the modal and the button
// //  const modal = document.getElementById("myModal");
// //  const btn = document.getElementById("submitButton");
// //  const span = document.getElementsByClassName("close")[0];

// //  // When the user clicks the button, open the modal
// //  btn.onclick = function() {
// //      modal.style.display = "block";
// //  }

// //  // When the user clicks on <span> (x), close the modal
// //  span.onclick = function() {
// //      modal.style.display = "none";
// //  }

// //  // When the user clicks anywhere outside of the modal, close it
// //  window.onclick = function(event) {
// //      if (event.target === modal) {
// //         modal.style.display = "none";
// //      }
// //  }

function postdel(){
    var msg = confirm("Do you want to delete post")
    console.log(msg)
}