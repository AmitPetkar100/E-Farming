from django.apps import AppConfig


class EFarmingAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'E_Farming_App'
