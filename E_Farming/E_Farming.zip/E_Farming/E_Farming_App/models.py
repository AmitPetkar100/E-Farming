from django.db import models
from autoslug import AutoSlugField
# Create your models here.
class registration(models.Model):
    first_name = models.CharField(max_length=50,null=True,default=None)
    last_name = models.CharField(max_length=50,null=True,default=None)
    mobile_number = models.CharField(max_length=10,null=True,default=None)
    country = models.CharField(max_length=50,null=True,default=None)
    state = models.CharField(max_length=50,null=True,default=None)
    district = models.CharField(max_length=50,null=True,default=None)
    taluka = models.CharField(max_length=50,null=True,default=None)
    village = models.CharField(max_length=50,null=True,default=None)
    pin_code = models.CharField(max_length=6,null=True,default=None)
    password = models.CharField(max_length=16,null=True,default=None)
    date = models.CharField(max_length=50,null=True,default=None)

class reg(models.Model):
    first_name = models.CharField(max_length=50,null=True,default=None)
    last_name = models.CharField(max_length=50,null=True,default=None)
    mobile_number = models.CharField(max_length=10,null=True,default=None)
    country = models.CharField(max_length=50,null=True,default=None)
    state = models.CharField(max_length=50,null=True,default=None)
    district = models.CharField(max_length=50,null=True,default=None)
    taluka = models.CharField(max_length=50,null=True,default=None)
    village = models.CharField(max_length=50,null=True,default=None)
    pin_code = models.CharField(max_length=6,null=True,default=None)
    password = models.CharField(max_length=16,null=True,default=None)
    date = models.CharField(max_length=50,null=True,default=None)

class category(models.Model):
    category = models.CharField(max_length=50,null=True,default=None)

class product(models.Model):
    user_id = models.BigIntegerField(null=True,default=None)
    title = models.CharField(max_length=50,null=True,default=None)
    contact_number = models.CharField(max_length=10,null=True,default=None)
    location = models.CharField(max_length=100,null=True,default=None)
    pro_category = models.CharField(max_length=50,null=True,default=None)
    pro_image = models.FileField(upload_to="product/",max_length=250,null=True,default=None)
    description = models.TextField()
    date = models.DateField(null=True,default=None)
    pro_slug = AutoSlugField(populate_from='title',unique=True,default=None,null=True)

class Trader(models.Model):
    first_name = models.CharField(max_length=50,null=True,default=None)
    last_name = models.CharField(max_length=50,null=True,default=None)
    mobile_number = models.CharField(max_length=10,null=True,default=None)
    address = models.CharField(max_length=50,null=True,default=None)
    pin_code = models.CharField(max_length=6,null=True,default=None)
    password = models.CharField(max_length=16,null=True,default=None)
    date = models.CharField(max_length=50,null=True,default=None)

class Notification(models.Model):
    Notification_message = models.CharField(max_length=50,null=True,default=None)
    product_id = models.CharField(max_length=50,null=True,default=None)
    category_id = models.CharField(max_length=50,null=True,default=None)
    farmer_id = models.CharField(max_length=50,null=True,default=None)
    trader_id = models.CharField(max_length=50,null=True,default=None)

class Review(models.Model):
    review_content = models.CharField(max_length=50,null=True,default=None)
    farmer_id = models.CharField(max_length=50,null=True,default=None)
    trader_id = models.CharField(max_length=50,null=True,default=None)

class AboutUs(models.Model):
    about_content = models.CharField(max_length=50,null=True,default=None)
    contact_no = models.CharField(max_length=50,null=True,default=None)
    contact_email = models.CharField(max_length=50,null=True,default=None)

    