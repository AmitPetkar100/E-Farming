from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render,redirect
from E_Farming_App.models import reg,product
from django.contrib.auth import authenticate,login
import re 
from datetime import date  
import base64
# Create your views here.

def login(request):
    if request.method == "POST":
        usermobile = request.POST.get('mobilenumber')
        userpass = request.POST.get('password')
        encodepass = base64.b64encode(userpass.encode("utf-8"))
        print(userpass)
        print(encodepass)

        mydata = reg.objects.filter(mobile_number = usermobile,password=encodepass).values('mobile_number')
        mydata2 = reg.objects.filter(mobile_number = usermobile,password=encodepass).values('password')
        mydata3 = reg.objects.filter(mobile_number = usermobile,password=encodepass).values('id')
        print(mydata)
        print(mydata2)
        print(mydata3)
        if (not((mydata)and(mydata2))):
            print('Empty')
            return render(request,"login.html",{'loginerror' : True})
        else:
            print('Correct')
            
            sessionusername = mydata[0]['mobile_number']
            sessionuserid = mydata3[0]['id']
            
            print("Username : ",mydata[0]['mobile_number'])
            print("user Id : ",mydata3[0]['id'])
            # Session code
            request.session['username'] = sessionusername
            request.session['userid'] = sessionuserid

            # return render(request,"index.html",{'usermobile' : sessionusername,'id':sessionuserid})
            return redirect("/",{'usermobile' : sessionusername,'id':sessionuserid})


        # if (mydata is not None) and (mydata2 is not None):
        #     return render(request,"index.html",{'usermobile' : usermobile})
        # else:
        #     return render(request,"login.html",{'loginerror' : True})

        # encodepass = base64.b64encode(userpass.encode("utf-8"))
        # print(userpass)
        # print(encodepass)
        # user = authenticate(mobile_number = usermobile,password = userpass)
        # if user is not None:
        #     login(request,user)
        #     return render(request,"index.html",{'usermobile' : usermobile})
        # else:
        #     return render(request,"login.html",{'loginerror' : True})
    return render(request,"login.html")

def index(request):
    # return HttpResponse('<h1><i>Hello your Application Run Successfully</i></h1>')
   
    # Get data from login user
    

    if 'username' in request.session and 'userid' in request.session:
        setsessionname = request.session['username']
        setsessionid = request.session['userid']
        print('Session1',setsessionname)
        print('Session2',setsessionid)
        # Fetch data from database by id and mobile number
        profile = reg.objects.filter(mobile_number=setsessionname).values()
        postdata = product.objects.filter(user_id=setsessionid).values()
        productdata = product.objects.all()
        
        profiledata = {
            'session1' : setsessionname,
            'session2':setsessionid,
            'firstname' : profile[0]['first_name'],
            'lastname' : profile[0]['last_name'],
            'mobile' : profile[0]['mobile_number'],
            'country' : profile[0]['country'],
            'state' : profile[0]['state'],
            'district' : profile[0]['district'],
            'taluka' : profile[0]['taluka'],
            'village' : profile[0]['village'],
            'pincode' : profile[0]['pin_code'],
            'productdata':productdata,
            'postdata':postdata,
            
        }
       
        return render(request,"index.html",profiledata)
    else:
        productdata = product.objects.all()
        # Searching Query
        if request.method == 'GET':
            st = request.GET.get('productName')
            if st != None:
                productdata =  product.objects.filter(title__icontains = st)

        profiledata = {
        'productdata':productdata,
        'session1':'',
        }
        return render(request,"index.html",profiledata)
    return render(request,"index.html",prodata)

def register(request):
    if request.method == "POST":
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        mnumber = request.POST.get('mnumber')
        country = request.POST.get('country')
        state = request.POST.get('state')
        district = request.POST.get('district')
        taluka = request.POST.get('taluka')
        village = request.POST.get('village')
        pincode = request.POST.get('pincode')
        cpassword = request.POST.get('cpassword')
        repassword = request.POST.get('repassword')
        regdate = date.today()
              
        a=re.fullmatch('[6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]',request.POST.get('mnumber')) 
        if request.POST.get('cpassword') != request.POST.get('repassword'):
            return render(request,"register.html",{'error' : True})
        elif a == None:                                                           
            return render(request,"register.html",{'mnumbererror' : True})
        elif reg.objects.filter(mobile_number = mnumber).exists():
            return render(request,"register.html",{'mnumexisterror' : True})
        else:
            encodepass = base64.b64encode(cpassword.encode("utf-8"))
            # print("encode password is  : ", encodepass)
            # Decoding the string
            # decodepass = base64.b64decode(encodepass).decode("utf-8")
            # print("byte-str : ", decodepass)

            savereg = reg(first_name = fname,last_name=lname,mobile_number=mnumber,country=country,state=state,district=district,taluka=taluka,village=village,pin_code=pincode,password=encodepass,date=regdate)
            savereg.save()
            return render(request,"register.html",{'regsuccess' : True})
    return render(request,"register.html")

def delsession(request):
    if 'username' in request.session and 'userid' in request.session:
        del request.session['username']
        del request.session['userid']
        # return render(request,"index.html",{'delsession':'Session deleted'})
        print('Session deleted')
        # print(request.session['username'])
        sessiondel = True
        return redirect("/")
    return render(request,"index.html")

def contact(request):
    return render(request,"contact.html")

def about(request):
    return render(request,"about.html")

def myprofile(request):

    if 'username' in request.session and 'userid' in request.session:
        setsessionname = request.session['username']
        setsessionid = request.session['userid']
        print('Session1',setsessionname)
        print('Session2',setsessionid)
        # Fetch data from database by id and mobile number
        profile = reg.objects.filter(mobile_number=setsessionname).values()
        # print(profile)
        profiledata = {
            'session1' : setsessionname,
            'session2':setsessionid,
            'firstname' : profile[0]['first_name'],
            'lastname' : profile[0]['last_name'],
            'mobile' : profile[0]['mobile_number'],
            'country' : profile[0]['country'],
            'state' : profile[0]['state'],
            'district' : profile[0]['district'],
            'taluka' : profile[0]['taluka'],
            'village' : profile[0]['village'],
            'pincode' : profile[0]['pin_code'],
            
        }
       
        return render(request,"profile.html",profiledata)
    
    return render(request,"profile.html")

def newpost(request):
    if 'username' in request.session and 'userid' in request.session:
        # setsessionname = request.session['username']
        setsessionid = request.session['userid']
        print('new post Session2',setsessionid)
        

    if request.method == "POST":
        title = request.POST.get('title')
        cnumber = request.POST.get('cnumber')
        location = request.POST.get('location')
        category = request.POST.get('category')
        proimage = request.FILES['proimage']
        description = request.POST.get('description')
        postdate = date.today()
        a=re.fullmatch('[6-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]',request.POST.get('cnumber'))
        if a == None:                                                           
            return render(request,"newpost.html",{'cnumbererror' : True})
        else:
            savepost = product(user_id = setsessionid,title=title,contact_number=cnumber,location=location,pro_category=category,pro_image=proimage,description=description,date=postdate)
            savepost.save()
            return render(request,"newpost.html",{'postsuccess' : True})


    return render(request,"newpost.html",{'userid':setsessionid})


def products(request):
    productdata = product.objects.all()
     # Searching Query
    if request.method == 'GET':
        st = request.GET.get('productName')
        if st != None:
            productdata =  product.objects.filter(title__icontains = st)
    productsdata = {
        'prooodata':productdata,
        }
    for p in productdata:
        print(p.title)
    return render(request,"products.html",productsdata)

def farmers(request):

    farmerdata = reg.objects.all()
    farmersdata = {
        'farmdata':farmerdata,
        }

    return render(request,"farmers.html",farmersdata)


def updatepost(request,postid):
    postdetails = product.objects.get(id = postid)

    updatepostdata = {
        'postdetails' : postdetails,
        'postid':postid,
        }
    
    if request.method == 'POST':
        title = request.POST.get('title')
        cnumber = request.POST.get('cnumber')
        location = request.POST.get('location')
        category = request.POST.get('category')
        description = request.POST.get('description')
        postdate = date.today()

        postdetails = product.objects.get(id = postid)
        try:
            if request.FILES['updateproimage']:
                print('You update the image.....')
                print('Updated images',request.FILES['updateproimage'])
                postdetails.pro_image = request.FILES['updateproimage']
        except:
            print('You not select any image')
            print('Default Image will be set : ',postdetails.pro_image)
            postdetails.pro_image = postdetails.pro_image

        postdetails.title = title
        postdetails.contact_number = cnumber
        postdetails.location = location
        postdetails.pro_category = category
        postdetails.description = description
        postdetails.date = postdate
        postdetails.save()
        return render(request,"updatepost.html",{'postupdated' : True})

        
    return render(request,"updatepost.html",updatepostdata)

def deletepost(request,delid):

    print("Post delete id : ",delid)
    # yesno = input("Type (y/n) to delete : ")
    # if yesno == 'y' or yesno == 'Y':
    #     print("Post deleted")
    #     print("Post delete id : ",delid)
    # elif yesno == 'N' or yesno == 'n':
    #     print("Post not deleted")
    postdelete = product.objects.get(id=delid)
    postdelete.delete()

    return redirect("/")

def search(request):
    searchresult =  product.objects.all()
    if request.method == 'GET':
        st = request.GET.get('productName')
        if st != None:
            searchresult =  product.objects.filter(title = st)
    searchdata={
        'searchresult':searchresult,
    }
    return render(request,"updatepost.html",searchdata)