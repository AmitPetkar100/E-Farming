from django.contrib import admin
from E_Farming_App.models import registration,reg,category,product,Trader,Notification,Review,AboutUs
# Register your models here.

class registrationAdmin(admin.ModelAdmin):
    list_display = ('first_name','last_name','mobile_number','country','state','district','taluka','village','pin_code','password','date')

# admin.site.register(registration,registrationAdmin)

# Start
class regAdmin(admin.ModelAdmin):
    list_display = ('first_name','last_name','mobile_number','country','state','district','taluka','village','pin_code','password','date')

admin.site.register(reg,regAdmin)

class categoryAdmin(admin.ModelAdmin):
    list_display = ('category',)
admin.site.register(category,categoryAdmin)

class productAdmin(admin.ModelAdmin):
    list_display=('user_id','title','contact_number','location','pro_category','pro_image','description','date','pro_slug')
admin.site.register(product,productAdmin)

class TraderAdmin(admin.ModelAdmin):
    list_display = ('first_name','last_name','mobile_number','address','pin_code','password','date')
admin.site.register(Trader,TraderAdmin)

class NotificationAdmin(admin.ModelAdmin):
    list_display = ('Notification_message','product_id','category_id','farmer_id','trader_id')
admin.site.register(Notification,NotificationAdmin)

class ReviewAdmin(admin.ModelAdmin):
    list_display = ('review_content','farmer_id','trader_id')
admin.site.register(Review,ReviewAdmin)

class AboutUsAdmin(admin.ModelAdmin):
    list_display = ('about_content','contact_no','contact_email')
admin.site.register(AboutUs,AboutUsAdmin)
