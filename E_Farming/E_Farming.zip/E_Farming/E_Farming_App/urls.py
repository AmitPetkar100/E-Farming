from django.urls import path
from E_Farming_App import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.index,name="index"),
    path('login/',views.login,name="login"),
    path('register/',views.register,name="register"),
    path('logout/',views.delsession,name="logout"),
    path('contact-us/',views.contact,name="contact"),
    path('about-us/',views.about,name="about"),
    path('myprofile/',views.myprofile,name="myprofile"),
    path('newpost/',views.newpost,name="newpost"),
    path('products/',views.products,name="products"),
    path('farmers/',views.farmers,name="farmers"),
    path('updatepost/<postid>',views.updatepost,name="updatepost"),
    path('deletepost/<delid>',views.deletepost,name="deletepost"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)